/* Included *after* config.h, in order to re-define these macros */

#ifdef PACKAGE
#undef PACKAGE
#endif

/* Name of package */
#define PACKAGE "openflow"

#ifdef VERSION
#undef VERSION
#endif

/* Version number of package */
#define VERSION "1.0.0" /* OpenFlowMajor.OpenFlowMinor.PluginRevForThisMajorMinorRev */
